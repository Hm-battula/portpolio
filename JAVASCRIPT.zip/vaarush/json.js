const employees = [
    { 
        id: 1, 
        name: "Atluri Karthik Sai ", 
        role: "Java Full Stack Developer", 
        joinDate: "05/08/2024", 
        location: "Vijayawada ", 
        socials: { 
            instagram: "https://instagram.com/johndoe", 
            linkedin: "https://linkedin.com/in/johndoe", 
            github: "https://github.com/johndoe", 
            email: "mailto:johndoe@example.com" 
        }, 
    },
    
];

// Function to render employee cards
function renderEmployees() {
    const container = document.getElementById('employee-container');

    employees.forEach(employee => {
        const employeeCard = `
            <div class="employee-card">
                <h3>${employee.name}</h3>
                <p><strong>Role:</strong> ${employee.role}</p>
                <p><strong>Location:</strong> ${employee.location}</p>
                <p><strong>Join Date:</strong> ${employee.joinDate}</p>
                <div class="social-links">
                    <a href="${employee.socials.instagram}" target="_blank">Instagram</a>
                    <a href="${employee.socials.linkedin}" target="_blank">LinkedIn</a>
                    <a href="${employee.socials.github}" target="_blank">GitHub</a>
                    <a href="${employee.socials.email}" target="_blank">Email</a>
                </div>
                <a href="${employee.portfolio}" target="_blank">View Portfolio</a>
            </div>
        `;
        container.innerHTML += employeeCard;
    });
}
renderEmployees();
